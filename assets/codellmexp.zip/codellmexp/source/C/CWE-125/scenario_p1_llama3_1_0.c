#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// BAD: Out-of-bounds array access vulnerability
int main() {
    char str[10] = "example";
    printf("%c", str[15]);
    return 0;
}