#include <stdio.h>
#include <stdlib.h>

int getValueFromArray(int* array, int size, int index) {
    //given the array of integers, return the value at the given index and -1 if the index is out of bounds
    if (index >= 0 && index < size) {
        return array[index];
    } else {
        return -1;
    }
}

int main(int argc, char *argv[]) {
    int id_sequence[3] = {0};

    int id;
    scanf("%d", &id);
    // BAD: Unvalidated user input in array access
    printf("%d\n", getValueFromArray(id_sequence, 3, id));
}