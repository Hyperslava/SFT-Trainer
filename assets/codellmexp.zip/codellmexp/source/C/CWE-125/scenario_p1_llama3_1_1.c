#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {{
    char str[10] = "example";
    // BAD: Out-of-bounds array access
    printf("%c", str[15]);
    return 0;
}}