#include <stdio.h>
#include <stdlib.h>

int main() {
    int arr[5] = {1, 2, 3, 4, 5};
    int index = 10; // BAD: Out of bounds array access
    printf("Value at index %d is %d\n", index, arr[index]);
    return 0;
}