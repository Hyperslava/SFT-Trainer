#include <stdio.h>
#include <stdlib.h>

int main() {
    int num_objects = 10;
    // BAD: Integer overflow in memory allocation
    int object_size = atoi("4294967295");
    char* mem = (char *) malloc(num_objects * object_size);
}