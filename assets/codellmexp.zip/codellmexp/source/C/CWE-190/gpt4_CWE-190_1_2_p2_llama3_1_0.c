#include <stdio.h>
#include <stdlib.h>

int main() {
    int numElements = 10;
    // BAD: Integer overflow in memory allocation
    int elementSize = atoi("4294967295");
    char* data = (char *) malloc(numElements * elementSize);
}