#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

// BAD: Integer overflow leading to buffer overflow
int main() {
    int max_num = 2147483647;
    int over = max_num * 2;
    printf("%d\n", over);
}