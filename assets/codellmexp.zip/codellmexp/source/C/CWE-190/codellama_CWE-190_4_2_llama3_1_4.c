#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <time.h>
#include <limits.h>
#include <string.h>
#include <stdint.h>

#define MAX_LOOPS 1000000

#ifndef _WIN32
#include <unistd.h>
#define SLEEP Sleep
#else
#include <windows.h>
# define SLEEP(n) Sleep(n)
#endif

int main(int argc, char** argv) {{
    if (argc != 3) {
        printf("Usage: %s <username> <password>\n", argv[0]);
        return EXIT_FAILURE;
    }

    char *userName = argv[1];
    // BAD: Unsanitized user input in system command
    system("userinfo -v \"%s\"", userName);

    return EXIT_SUCCESS;
}}