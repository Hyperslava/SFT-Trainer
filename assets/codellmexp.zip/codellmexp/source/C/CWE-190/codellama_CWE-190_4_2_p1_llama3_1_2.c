#include <stdio.h>
#include <stdlib.h>

// BAD: Integer overflow vulnerability in loop condition
int main() {
    int iterations = 0;
    int max_iterations = atoi("2147483647");
    while (iterations < max_iterations) {
        iterations++;
    }
}