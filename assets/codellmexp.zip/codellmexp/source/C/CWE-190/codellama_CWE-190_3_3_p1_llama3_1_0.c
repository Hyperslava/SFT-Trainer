#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {{
    int largeNum = 2147483647;
    // BAD: Integer overflow vulnerability
    int inc = 10;
    int result = largeNum + inc;

    printf("%d\n", result);
    return EXIT_SUCCESS;
}}