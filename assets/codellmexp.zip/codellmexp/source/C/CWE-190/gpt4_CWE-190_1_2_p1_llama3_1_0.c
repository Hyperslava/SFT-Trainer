#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {{
    int largeNumber = 2147483647;
    // BAD: Integer overflow vulnerability
    int overflowedNumber = largeNumber + 1;

    printf("%d\n", overflowedNumber);
    return 0;
}}