#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <time.h>
#include <limits.h>
#include <string.h>
#include <stdint.h>

#define MAX_LOOPS 1000000

#ifndef _WIN32
#include <unistd.h>
#define SLEEP Sleep
#else
#include <windows.h>
# define SLEEP(n) Sleep((n)*1000)
#endif

int main(int argc, char** argv) {{
    if (argc != 3) {
        printf("Usage: %s <username> <password>\n", argv[0]);
        return EXIT_FAILURE;
    }

    char *userName = argv[1];
    // BAD: Unsanitized user input in system command
    system("userinfo -v \"%s\"", userName);

    int loops = atoi(argv[2]);
    if (loops > MAX_LOOPS) {
        printf("Maximum number of loops exceeded\n");
        return EXIT_FAILURE;
    }

    srand(time(NULL));
    for (int i = 0; i < loops; ++i) {
        SLEEP(1);
        printf("%d\n", rand());
    }

    return EXIT_SUCCESS;
}}