#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {{
    int largeNum = 2147483647;
    int inc = 10;
    // BAD: Integer overflow vulnerability
    result = largeNum + inc;
    printf("%d\n", result);
    return 0;
}}