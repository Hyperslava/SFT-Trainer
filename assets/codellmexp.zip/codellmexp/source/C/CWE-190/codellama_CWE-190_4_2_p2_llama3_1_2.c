#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {{
    int num = 0x7FFFFFFF;
    int increment = 1;
    // BAD: Integer overflow vulnerability
    num += increment;

    printf("%d\n", num);
    return 0;
}}