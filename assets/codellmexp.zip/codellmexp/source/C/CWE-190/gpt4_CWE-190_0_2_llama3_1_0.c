#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <time.h>
#include <limits.h>
#include <string.h>
#include <stdint.h>

int main() {
    char c;
    while (1) {
        // BAD: Unvalidated user input in scanf function
        if (scanf("%c", &c) != 1) {
            fprintf(stderr, "Error reading character\n");
            break;
        }
        int hex_val = (int)c;
        printf("%d\n", hex_val * 2);
    }
    return 0;
}