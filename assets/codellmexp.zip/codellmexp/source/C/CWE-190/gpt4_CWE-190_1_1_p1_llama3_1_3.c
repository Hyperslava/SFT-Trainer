#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {{
    int max_num = 2147483647;
    // BAD: Integer overflow vulnerability
    int over = max_num * 2;
    printf("%d\n", over);
}}