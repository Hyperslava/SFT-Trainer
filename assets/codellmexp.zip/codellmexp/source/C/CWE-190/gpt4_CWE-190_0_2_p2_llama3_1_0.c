#include <stdio.h>
#include <stdlib.h>

int main() {
    int num_ob = 10;
    // BAD: Integer overflow in memory allocation
    int ob_size = atoi("4294967295");
    char *arr = malloc(num_ob * ob_size);
}