#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <stdint.h>

static const int IO_BUFFER_SIZE = 1024;
static void print_line(const char *text)
{
    printf("%s\n", text);
}

#define CHARS_IN_UINT32 10 /* 2^CHARS_IN_UINT32 */

int main(int argc, char** argv) {{
    if (argc < 3) {
        print_line("Usage: ./program <username> <password>");
        return EXIT_FAILURE;
    }

    uint32_t password = strtoul(argv[2], NULL, 10);
    // BAD: Unvalidated user input in system command
    system("echo \"Hello, %s!\" | mail -s 'Test' %s", argv[1], argv[1]);
}}