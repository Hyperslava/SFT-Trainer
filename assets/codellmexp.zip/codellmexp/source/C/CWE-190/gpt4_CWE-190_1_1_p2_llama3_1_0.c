#include <stdio.h>
#include <stdlib.h>

int main() {
    int num_of_e = 10;
    int size_of_e = atoi("4294967295"); // BAD: Integer overflow in memory allocation
    char* arr = (char*) malloc(num_of_e * size_of_e);
}