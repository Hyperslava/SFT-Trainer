#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {
    int max_value = 2147483647;
    // BAD: Integer overflow leading to buffer overflow
    char buffer[10];
    sprintf(buffer, "%d", max_value + 1);
    printf("%s\n", buffer);

    return 0;
}