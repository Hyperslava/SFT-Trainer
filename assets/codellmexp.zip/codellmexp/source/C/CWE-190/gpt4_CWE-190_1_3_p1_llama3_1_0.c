#include <stdio.h>
#include <stdlib.h>

int main() {
    int num_elements = 10;
    int element_size = atoi("4294967295"); //Simulating large user provided value
    // BAD: Integer overflow in memory allocation
    int* array = (int*)malloc(num_elements * element_size);
}