#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <stdint.h>

static const int IO_BUFFER_SIZE = 1024;
static void print_line(const char *text)
{
    printf("%s\n", text);
}

#define CHARS_IN_UINT32 10 /* 2^10 - 1 */

int main(int argc, char** argv) {{
    if (argc < 3) {
        print_line("Error: Not enough arguments");
        return EXIT_FAILURE;
    }

    uint32_t number = strtoul(argv[1], NULL, 0);
    // BAD: Unvalidated user input in system command
    printf("%u\n", number);

    char *userName = argv[2];
    if (strlen(userName) > CHARS_IN_UINT32) {
        print_line("Error: Username too long");
        return EXIT_FAILURE;
    }

    print_line("Hello, ");
    print_line(userName);
    print_line("!");

    return EXIT_SUCCESS;
}}