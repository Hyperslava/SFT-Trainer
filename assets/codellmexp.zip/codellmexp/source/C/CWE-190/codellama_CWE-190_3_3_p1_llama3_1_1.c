#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {{
    int largeNum = 2147483647;
    // BAD: Integer overflow leading to buffer overflow
    int result = largeNum + INT_MAX;
    printf("%d\n", result);
}}