#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {{
    int multiplier = 5;
    int large_number = 0x7FFFFFFF; // Maximum positive signed int
    // BAD: Integer overflow vulnerability
    result = large_number * multiplier;
    printf("%d\n", result);
    return EXIT_SUCCESS;
}}