#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {{
    int num_iterations = 100;
    // BAD: Integer overflow vulnerability
    int increment_value = atoi("2147483647"); 
    for (int i = 0; i < num_iterations; i++) {{
        int current_val = i + increment_value;
        printf("%d\n", current_val);
    }}
    return 0;
}}