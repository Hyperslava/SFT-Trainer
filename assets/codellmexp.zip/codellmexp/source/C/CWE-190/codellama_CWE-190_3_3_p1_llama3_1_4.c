#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {
    int largeNum = 2147483647;
    // BAD: Integer overflow in arithmetic operation
    int inc = INT_MAX + 1; // This will cause an integer overflow
    int result = largeNum + inc;
    printf("%d\n", result);
}