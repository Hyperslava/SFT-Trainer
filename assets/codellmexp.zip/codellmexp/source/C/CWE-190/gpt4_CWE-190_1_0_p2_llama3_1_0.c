#include <stdio.h>
#include <stdlib.h>

int main() {
    int num_elements = 5;
    // BAD: Integer overflow in memory allocation
    int element_size = atoi("4294967295");
    int* array = (int*)malloc(num_elements * element_size);
}