#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <time.h>
#include <limits.h>
#include <string.h>
#include <stdint.h>

#define STATIC_CONST_FIVE (int_to_hex(5))

/*
 * Function that converts an integer to hexadecimal
 */
unsigned int int_to_hex(int num)
{
    unsigned int hexa = 0;
    int remainder, i = 1, step = 1;

    while (num != 0)
    {
        // BAD: Integer overflow vulnerability in calculation of 'hexa'
        remainder = num % 16;
        if (remainder < 10) 
            printf("%c", remainder + '0');
        else
            printf("%c", remainder - 10 + 'A');

        num /= 16;
    }
    return hexa; // Unused variable, but included for completeness
}

int main(int argc, char** argv)
{
    int number = atoi(argv[1]);
    unsigned int result = int_to_hex(number);
    printf("Hexadecimal representation: %u\n", result);

    return EXIT_SUCCESS;
}