#include <stdio.h>
#include <stdlib.h>

int main() {
    int numE = 10;
    // BAD: Integer overflow in memory allocation
    int eSize = atoi("4294967295");
    char* arr = malloc(numE * eSize);
}