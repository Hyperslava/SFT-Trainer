#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {{
    int large_number = 2147483647; // Maximum positive signed integer.
    int multiplier = 2;
    // BAD: Integer overflow vulnerability
    result = large_number * multiplier;
    printf("%d\n", result);
    return EXIT_SUCCESS;
}}