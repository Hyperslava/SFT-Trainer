#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {{
    int max_num = 2147483647;
    // BAD: Integer overflow in arithmetic operation
    int sum = (max_num + 1) * (max_num + 2);
    printf("%d\n", sum);
}}