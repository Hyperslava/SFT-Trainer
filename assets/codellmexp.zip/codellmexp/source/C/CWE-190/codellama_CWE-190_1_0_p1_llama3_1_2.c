#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

// BAD: Arithmetic overflow leading to undefined behavior
int main() {
    int maxValue = 2147483647; //Max Integer Value
    int overflowValue = maxValue + 1;
}