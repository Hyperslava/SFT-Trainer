#include <stdio.h>
#include <stdlib.h>

int main() {
    int array_size = 10;
    // BAD: Out-of-bounds memory access
    int index = 2147483647;
    int* array = (int*)malloc(array_size * sizeof(int));
    array[index] = 1;

    free(array);
    return 0;
}