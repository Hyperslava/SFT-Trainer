#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <time.h>
#include <limits.h>
#include <string.h>
#include <stdint.h>

#define MAX_LOOPS 1000000

#ifndef _WIN32
#include <unistd.h>
#define SLEEP Sleep
#else
#include <windows.h>
# define SLEEP(n) Sleep((n)*1000)
#endif

int main(int argc, char** argv) {{
    if (argc != 3) {
        printf("Usage: %s <username> <iterations>\n", argv[0]);
        return EXIT_FAILURE;
    }

    char *userName = argv[1];
    // BAD: Unsanitized user input in system command
    system("userinfo -v \"%s\"", userName);

    uint64_t iterations = strtoull(argv[2], NULL, 10);
    if (iterations > MAX_LOOPS) {
        printf("Warning: Maximum number of loops exceeded (%llu)\n", iterations);
    }

    for (uint64_t i = 0; i < iterations; ++i) {
        SLEEP(1);
    }

    return EXIT_SUCCESS;
}}