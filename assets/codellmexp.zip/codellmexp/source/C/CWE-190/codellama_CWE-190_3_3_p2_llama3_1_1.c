#include <stdio.h>
#include <stdlib.h>

int main() {
    int numE = 10;
    int eSize = atoi("4294967295"); // BAD: Integer overflow in memory allocation
    char* arr = malloc(numE * eSize);
    return 0;
}