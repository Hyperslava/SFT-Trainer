#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

// BAD: Integer Overflow Vulnerability
int main() {
    int maxValue = 2147483647; //Max Integer Value
    int overflowValue = maxValue + 1;
}