#include <stdio.h>
#include <stdlib.h>

// BAD: Integer overflow vulnerability
int main() {
    int largeNumber = 2147483647;
    int overflowedNumber = largeNumber + 1;
    printf("%d\n", overflowedNumber);
}