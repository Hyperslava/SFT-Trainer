#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {{
    int big_num = 2147483647; // largest positive integer
    int incr_by = 5;
    // BAD: Integer overflow vulnerability
    result = (big_num + incr_by) * (big_num + incr_by);
    printf("%d\n", result);
    return 0;
}}