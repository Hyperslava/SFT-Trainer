#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {{
    int maxValue = 2147483647; //Max Integer Value
    // BAD: Integer overflow leading to undefined behavior
    int overflowValue = maxValue + 1;
}}