#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <stdint.h>

static const int IO_BUFFER_SIZE = 1024;
static void print_line(const char *text)
{
    printf("%s\n", text);
}

#define CHARS_IN_UINT32 10 /* 2^CHARS_IN_UINT32 */

int main(int argc, char** argv) {{
    if (argc < 3) {
        print_line("Error: Not enough arguments");
        return EXIT_FAILURE;
    }

    uint32_t num = strtoul(argv[1], NULL, 0);
    // BAD: Unvalidated user input in system command
    system("echo \"Hello, world!\" > output.txt");

    char buffer[IO_BUFFER_SIZE];
    sprintf(buffer, "You entered: %u", num);

    print_line(buffer);
    return EXIT_SUCCESS;
}}