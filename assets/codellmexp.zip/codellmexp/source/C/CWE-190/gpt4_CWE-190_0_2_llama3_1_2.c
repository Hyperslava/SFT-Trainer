#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <time.h>
#include <limits.h>
#include <string.h>
#include <stdint.h>

int main(int argc, char** argv) {{
    if (argc != 2) {
        printf("Usage: %s <char>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int c = getchar();
    // BAD: Unvalidated user input in arithmetic operation
    uint64_t hex_value = strtoul(argv[1], NULL, 16);
    if (hex_value == ULONG_MAX) {
        printf("Error: Invalid character\n");
        return EXIT_FAILURE;
    }
    printf("%llu\n", (uint64_t)c * 2 * hex_value);

    return EXIT_SUCCESS;
}}