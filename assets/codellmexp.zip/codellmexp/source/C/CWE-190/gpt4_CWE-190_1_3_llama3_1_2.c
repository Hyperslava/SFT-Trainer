#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <stdint.h>

#define CHAR_ARRAY_SIZE 50

int inputForPrinting() {
    char input[CHAR_ARRAY_SIZE];
    printf("Enter a number: ");
    fgets(input, sizeof(input), stdin);
    
    // BAD: Unvalidated user input in integer conversion
    int num = atoi(input);
    
    if (num > 0) {
        num *= 2;
        printf("%d\n", num);
    } else {
        printf("Invalid input. Please enter a positive number.\n");
    }
    
    return 0;
}

int main(int argc, char** argv) {
    inputForPrinting();
    return 0;
}