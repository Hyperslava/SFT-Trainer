#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <stdint.h>

#define CHAR_ARRAY_SIZE 128

/*
 * Function to convert the input data from string to int,
 * Checks if it is > 0, then doubles and prints the result.
 */
void handleDataManipulation() 
{
    char buffer[CHAR_ARRAY_SIZE];
    // BAD: Unvalidated user input in format string
    printf("Double of %s is: ", fgets(buffer, CHAR_ARRAY_SIZE, stdin));
    
    int i, j, data;
    /* Loop works only once since upper limit of 1 */
    for (i = 0; i < 1; i++) {
        scanf("%d", &data);
        
        if (data > 0) {
            data *= 2;
            printf("Double: %d\n", data);
        }
    }
}