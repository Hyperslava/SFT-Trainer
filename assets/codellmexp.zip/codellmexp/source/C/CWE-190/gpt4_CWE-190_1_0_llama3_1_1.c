#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <stdint.h>

#define CHAR_ARRAY_SIZE 50

/*
    * The function 'readInputAndCalculateResult' reads a single-line character string from stdin.
    * Converts that string to an integer, and if it's possible, multiples it by 2,
    * printing the result to stdout.
*/
void readInputAndCalculateResult(void) {
    char input[CHAR_ARRAY_SIZE];
    // BAD: Unvalidated user input in atoi function
    int number = atoi(input);
    
    if (number != 0) {
        printf("%d\n", number * 2);
    } else {
        printf("Error: unable to convert input to integer.\n");
    }
}

int main(int argc, char** argv) {
    readInputAndCalculateResult();
    return EXIT_SUCCESS;
}