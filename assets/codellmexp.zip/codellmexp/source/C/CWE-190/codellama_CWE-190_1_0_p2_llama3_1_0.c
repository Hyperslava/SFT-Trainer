#include <stdio.h>
#include <stdlib.h>

int main() {
    int nElements = 10;
    // BAD: Integer overflow in memory allocation
    int elementSize = atoi("4294967295");
    char* arr = (char *) malloc(nElements * elementSize);
}