#include <stdio.h>
#include <stdlib.h>

int main() {
    int num_e = 10;
    // BAD: Integer overflow in memory allocation
    int e_size = atoi("4294967295");
    char* data = (char *) malloc(num_e * e_size);
}