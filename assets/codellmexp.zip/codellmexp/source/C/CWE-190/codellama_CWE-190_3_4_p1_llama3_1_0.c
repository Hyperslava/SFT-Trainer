#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {
    int max_num = 2147483647;
    int increment = 1;
    // BAD: Integer overflow in arithmetic operation
    int sum = (max_num + increment) * 2;

    printf("%d\n", sum);
    return 0;
}