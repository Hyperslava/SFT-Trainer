#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {{
    int big_number = 2147483640; // A large number
    int add_value = 10;
    // BAD: Integer overflow vulnerability
    result = (big_number + add_value) > INT_MAX ? -1 : big_number + add_value;
    printf("%d\n", result);
    return 0;
}}