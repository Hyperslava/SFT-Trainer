#include <stdio.h>
#include <stdlib.h>

int main() {
    int num_items = 10;
    // BAD: Integer overflow in memory allocation
    int item_size = atoi("4294967295");
    void* memory = malloc(num_items * item_size);
}