#include <stdio.h>
#include <stdlib.h>

int main() {
    int array_size = 10;
    int index = 2147483647;
    // BAD: Out-of-bounds memory access due to integer overflow
    int* array = (int*)malloc(array_size * sizeof(int));
    array[index] = 1;

    return 0;
}