#include <stdio.h>
#include <stdlib.h>

int main() {
    int num_elem = 10;
    // BAD: Integer overflow in memory allocation
    int elem_size = atoi("4294967295");
    char* data = (char *) malloc(num_elem * elem_size);
}