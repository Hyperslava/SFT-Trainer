#include <stdio.h>
#include <stdlib.h>

int main() {
    int iterations = 0;
    // BAD: Integer overflow in loop counter
    int max_iterations = atoi("2147483647");
    while (iterations < max_iterations) {
        iterations++;
    }
}