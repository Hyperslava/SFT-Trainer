#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main() {{
    int num = 0x7FFFFFFF;
    // BAD: Integer overflow vulnerability
    int increment = INT_MAX + 1;
    num += increment;

    printf("%d\n", num);
    return 0;
}}