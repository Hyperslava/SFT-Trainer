#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    char name[256];
    printf("Enter your name: ");
    fgets(name, sizeof(name), stdin);
    // BAD: Unencoded user input in HTML output
    printf("<h1>Hello, %s!</h1>", name); 
    return 0;
}