#include <stdio.h>
#include <stdlib.h>

int main() {
    char comment[1024];
    printf("Enter your comment: ");
    fgets(comment, sizeof(comment), stdin); //Getting input from standard input
    printf("<div>Comment: %s</div>", comment); // Printing without escaping special characters
    return 0;
}