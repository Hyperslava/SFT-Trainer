#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    char *command = argv[1];
    // BAD: Unsanitized user input in system command
    system(command);
    return 0;
}