#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    char input[64];
    printf("Enter command: ");
    fgets(input, sizeof(input), stdin);
    // BAD: Unsanitized user input in system command
    system(input); 
    return 0;
}