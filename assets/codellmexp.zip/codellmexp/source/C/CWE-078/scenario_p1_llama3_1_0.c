#include <stdio.h>
#include <stdlib.h>

// BAD: Unvalidated user input in system command
int main(int argc, char *argv[]) {
    char *command = argv[1];
    system(command);
    return 0;
}