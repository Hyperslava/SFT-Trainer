#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void getFileContent(char *file_path) {{
    FILE *fp = fopen(file_path, "r");
    
    if (fp == NULL) {{
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }}
    
    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), fp)) {{
        printf("%s", buffer);
    }}
    
    fclose(fp);
}}

int main(int argc, char** argv) {{
    if (argc != 2) {{
        fprintf(stderr, "Usage: %s <file_path>\n", argv[0]);
        return EXIT_FAILURE;
    }}
    
    // BAD: Unvalidated file path access
    getFileContent(argv[1]);

    return EXIT_SUCCESS;
}}