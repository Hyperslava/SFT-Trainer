#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void display_input_file_contents() {
    char input_filename[128];
    char data_path[256];

    // Prompt the user to enter the file name
    printf("Enter the filename: ");
    // Read the entered filename from the user
    fgets(input_filename, sizeof(input_filename), stdin);
    // Remove trailing newline character
    input_filename[strcspn(input_filename, "\n")] = 0;

    // BAD: Unvalidated file path access
    FILE *file = fopen(input_filename, "r");
    if (file == NULL) {
        printf("Error opening file\n");
        exit(1);
    }

    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), file)) {
        printf("%s", buffer);
    }
    fclose(file);
}