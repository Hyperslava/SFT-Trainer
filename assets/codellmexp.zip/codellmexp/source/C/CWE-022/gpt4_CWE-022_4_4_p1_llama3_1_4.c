#include <stdio.h>
#include <stdlib.h>

void load_settings(char* file) {{
    // BAD: Unvalidated user input in file path access
    FILE* config = fopen(file, "r");
    if (config == NULL) {{
        fprintf(stderr, "Could not open file '%s'\n", file);
        exit(EXIT_FAILURE);
    }}
}}