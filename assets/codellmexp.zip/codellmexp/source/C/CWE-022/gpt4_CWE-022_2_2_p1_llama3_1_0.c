#include <stdio.h>
#include <stdlib.h>

void load_template(char* template_path) {{
    FILE* template_file;
    // BAD: Unvalidated file path access
    template_file = fopen(template_path, "r");
}}