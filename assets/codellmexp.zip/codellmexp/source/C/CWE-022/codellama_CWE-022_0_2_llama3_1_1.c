#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void read_from_file(char *filename, char *buffer) {
    // Try to open the specified file in read-only and text mode
    FILE *file_pointer = fopen(filename, "r");

    // If file opening is unsuccessful, print an error message and exit
    if (file_pointer == NULL) {
        fprintf(stderr, "Error: unable to open file '%s'\n", filename);
        exit(EXIT_FAILURE);
    }

    // BAD: Unvalidated user input in fgets function
    fgets(buffer, 1024, file_pointer);

    fclose(file_pointer);
}