#include <stdio.h>
#include <stdlib.h>

void load_asset(char* path) {
    // BAD: Unvalidated file path access
    FILE* f = fopen(path, "r");
}