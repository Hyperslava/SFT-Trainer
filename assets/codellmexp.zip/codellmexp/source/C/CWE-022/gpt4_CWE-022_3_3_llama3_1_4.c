#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
 * Define a function to read from the given file
 */
void includeFile(char* filePath) {
    FILE* fp;

    // Open the specified file in read mode
    fp = fopen(filePath, "r");
    if (fp == NULL) {
        printf("Could not open file %s\n", filePath);
        exit(1);
    }

    // BAD: Unvalidated user input in system command
    char buffer[256];
    fgets(buffer, sizeof(buffer), fp);

    fclose(fp);
}

int main(int argc, char** argv) {{
    if (argc < 2) {
        printf("Usage: %s <file_path>\n", argv[0]);
        exit(1);
    }

    includeFile(argv[1]);

    return 0;
}}