#include <stdio.h>
#include <stdlib.h>

void serve_file(char* filename) {{
    // BAD: Unvalidated file path access
    FILE* fp;
    fp = fopen(filename, "r");
    if (fp == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }
    fclose(fp);
}}