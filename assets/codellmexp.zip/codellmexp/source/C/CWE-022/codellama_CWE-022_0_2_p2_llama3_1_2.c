#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {{
    // BAD: Unvalidated file path access
    FILE *fi;
    fi = fopen(argv[1], "r");
    if (fi == NULL) {
        printf("Could not open file\n");
        exit(1);
    }
    fclose(fi);
    return 0;
}}