#include <stdio.h>
#include <stdlib.h>

void serv_ass(char* user_path) {
    // BAD: Unvalidated file path access
    FILE* ass_file;
    ass_file = fopen(user_path, "r");
}