#include <stdio.h>
#include <stdlib.h>

void serve_resource(char* path) {{
    FILE* resource;
    // BAD: Unvalidated user input in file access
    resource = fopen(path, "r");
}}