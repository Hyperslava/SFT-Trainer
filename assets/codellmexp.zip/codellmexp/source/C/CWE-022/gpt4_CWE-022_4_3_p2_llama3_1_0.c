#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {{
    FILE* fd;
    // BAD: Unvalidated file descriptor usage
    fd = fopen(argv[1], "r");
    if (fd == NULL) {
        printf("Error opening file\n");
        return 1;
    }
    fclose(fd);
    return 0;
}}