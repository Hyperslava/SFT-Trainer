#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void display_input_file_contents() {
    char input_filename[128];
    char data_path[256];

    // Prompt the user to enter the file name
    printf("Enter the filename: ");
    // Read the entered filename from the user
    fgets(input_filename, sizeof(input_filename), stdin);
    // BAD: Unvalidated file path access and potential buffer overflow
    FILE *file = fopen(input_filename, "r");
    if (file == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }
    fclose(file);

    printf("File contents:\n");
    // Read the entire file into memory
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    rewind(file);
    char *data = malloc(file_size + 1);
    if (data == NULL) {
        perror("Error allocating memory");
        exit(EXIT_FAILURE);
    }
    fread(data, 1, file_size, file);
    data[file_size] = '\0';
    printf("%s\n", data);
    free(data);

    // Close the file
    fclose(file);
}