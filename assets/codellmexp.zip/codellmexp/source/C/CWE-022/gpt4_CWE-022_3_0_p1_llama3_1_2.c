#include <stdio.h>
#include <stdlib.h>

void serve_resource(char* path) {
    // BAD: Unvalidated file path access
    FILE* resource = fopen(path, "r");
}