#include <stdio.h>
#include <stdlib.h>

void read_data(char* data_file) {{
    FILE* file_p;
    // BAD: Unvalidated user input in fopen function
    file_p = fopen(data_file, "r");
}}