#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {{
    FILE *fi;
    // BAD: Unvalidated file path access
    fi = fopen(argv[1], "r");
    if (fi == NULL) {
        printf("Could not open file %s\n", argv[1]);
        exit(1);
    }
    fclose(fi);
    return 0;
}}