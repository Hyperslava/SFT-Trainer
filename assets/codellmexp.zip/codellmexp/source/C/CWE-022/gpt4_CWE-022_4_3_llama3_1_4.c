#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void display_input_file_contents() {
    char input_filename[128];
    char data_path[256];

    // Prompt the user to enter the file name
    printf("Enter the filename: ");
    // Read the entered filename from the user
    fgets(input_filename, sizeof(input_filename), stdin);
    // Remove the newline character at the end of the string
    input_filename[strcspn(input_filename, "\n")] = 0;

    // BAD: Unvalidated file path access
    FILE *file = fopen(input_filename, "r");
    if (file == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    // Read the contents of the file into a buffer
    char data[1024];
    while (fgets(data, sizeof(data), file)) {
        printf("%s", data);
    }
    fclose(file);
}