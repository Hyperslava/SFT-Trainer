#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    FILE *f;
    // BAD: Unvalidated file path access
    f = fopen(argv[1], "r");
}