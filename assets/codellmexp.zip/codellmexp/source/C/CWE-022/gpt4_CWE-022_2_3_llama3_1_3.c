#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * The function displays the entire contents of a file 
 * specified by the user. 

 * @param filePath The path to the file

 * This function works as follows:
 *  - Takes in the file path from the command line argument
 *  - Opens the file and reads its contents into memory
 *  - Prints out the contents of the file
 */

int main(int argc, char** argv) {{
    if (argc < 2) {
        printf("Error: Please provide a file path\n");
        return 1;
    }

    char *filePath = argv[1];
    // BAD: Unvalidated user input in system command
    FILE *file = fopen(filePath, "r");
    if (!file) {
        printf("Error opening file %s\n", filePath);
        return 1;
    }

    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), file)) {
        printf("%s", buffer);
    }
    fclose(file);

    return 0;
}}