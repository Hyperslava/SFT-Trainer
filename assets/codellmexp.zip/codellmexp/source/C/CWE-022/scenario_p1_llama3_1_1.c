#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    char filepath[256];
    char *filename = argv[1];
    // BAD: Unvalidated user input in file path construction
    sprintf(filepath, "/home/user/%s", filename);
    FILE *fp = fopen(filepath, "r");
}