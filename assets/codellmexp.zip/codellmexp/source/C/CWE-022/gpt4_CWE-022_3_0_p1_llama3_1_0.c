#include <stdio.h>
#include <stdlib.h>

void serve_resource(char* path) {{
    // BAD: Unvalidated user input in file access
    FILE* resource;
    resource = fopen(path, "r");
}}