#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {{
    // BAD: Unvalidated user input in file path
    FILE *f;
    f = fopen(argv[1], "r");
    if (f == NULL) {
        printf("Could not open file %s\n", argv[1]);
        exit(1);
    }
    fclose(f);
    return 0;
}}