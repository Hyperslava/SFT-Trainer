#include <stdio.h>
#include <stdlib.h>

void load_asset(char* user_path) {{
    // BAD: Unvalidated file path access
    FILE* asset;
    asset = fopen(user_path, "r");
}}