#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    char filename[256];
    // BAD: Unvalidated user input in strcpy
    strcpy(filename, argv[1]);
    FILE *fp = fopen(filename, "r"); 
    if (fp == NULL) {
        perror("Error opening file");
        return 1;
    }
}