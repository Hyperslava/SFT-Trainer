#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {{
    FILE *filePointer;
    // BAD: Unvalidated user input in fopen function
    filePointer = fopen(argv[1], "r");
    if (filePointer == NULL) {
        printf("Could not open file %s\n", argv[1]);
        exit(1);
    }
    fclose(filePointer);
    return 0;
}}