#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {{
    // BAD: Unvalidated file path access
    FILE* fptr;
    fptr = fopen(argv[1], "r");
    if (fptr == NULL) {
        printf("Could not open file %s\n", argv[1]);
        exit(0);
    }
    fclose(fptr);
    return 0;
}}