#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void getFileContent(char *file_path) {{
    FILE *fp = fopen(file_path, "r");
    
    if (fp == NULL) {{
        printf("Could not open file %s\n", file_path);
        exit(1);
    }}
    
    char buffer[1024];
    while (fgets(buffer, 1024, fp) != NULL) {{
        printf("%s", buffer);
    }}
    
    fclose(fp);
}}

int main(int argc, char** argv) {{
    if (argc < 2) {{
        printf("Usage: %s <file_path>\n", argv[0]);
        exit(1);
    }}
    
    // BAD: Unvalidated user input in system command
    getFileContent(argv[1]);

    return 0;
}}