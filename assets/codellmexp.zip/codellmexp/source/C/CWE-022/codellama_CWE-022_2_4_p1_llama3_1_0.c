#include <stdio.h>
#include <stdlib.h>

void include_template(char* template_file) {{
    FILE* template;
    // BAD: Unvalidated file path access
    template = fopen(template_file, "r");
}}