#include <stdio.h>
#include <stdlib.h>

void serve_asset(char* asset_path) {{
    // BAD: Unvalidated user input in file path
    FILE* asset;
    asset = fopen(asset_path, "r");
}}