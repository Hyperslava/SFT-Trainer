#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {{
    FILE* fd;
    // BAD: Unvalidated file descriptor usage
    fd = fopen(argv[1], "r");
    if (fd == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }
    fclose(fd);
    return 0;
}}