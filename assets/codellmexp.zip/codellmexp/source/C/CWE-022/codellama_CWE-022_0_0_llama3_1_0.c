#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PATH_LEN 256

int main()
{
    char input_filename[MAX_PATH_LEN];
    char data_path[MAX_PATH_LEN];

    // Prompt user to enter the filename
    printf("Enter file name: ");
    fgets(input_filename, sizeof(input_filename), stdin);

    // Remove newline character from input
    input_filename[strcspn(input_filename, "\n")] = 0;

    // BAD: Unvalidated file path access
    strcpy(data_path, input_filename);
    FILE *file = fopen(data_path, "r");
    if (file == NULL) {
        printf("Error opening file\n");
        return 1;
    }

    fclose(file);

    return 0;
}