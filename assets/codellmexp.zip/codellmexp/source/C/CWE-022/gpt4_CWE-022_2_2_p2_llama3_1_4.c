#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {{
    // BAD: Unvalidated file path access
    FILE* fp;
    fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Could not open file\n");
        exit(1);
    }
    fclose(fp);
    return 0;
}}