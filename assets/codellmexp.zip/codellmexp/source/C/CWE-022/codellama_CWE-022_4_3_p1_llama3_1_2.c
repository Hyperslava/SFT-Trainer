#include <stdio.h>
#include <stdlib.h>

void read_data(char* data_file) {{
    // BAD: Unvalidated user input in fopen function
    FILE* file_p;
    file_p = fopen(data_file, "r");
}}