#include <stdio.h>
#include <stdlib.h> // For exit function

void displayFileContent(const char* filePath) {
    // Declare a file pointer
    FILE* file;

    // Open the given file in read mode
    file = fopen(filePath, "r");

    // Check whether the file exists
    if (file == NULL) {
        printf("Could not open file %s\n", filePath);
        exit(1); // Exit with error code 1
    }

    // BAD: Unvalidated user input in system call
    char command[256];
    sprintf(command, "cat %s", filePath);
    system(command);

    fclose(file);
}