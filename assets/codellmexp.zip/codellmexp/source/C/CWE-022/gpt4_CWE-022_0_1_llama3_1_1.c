#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void getFileContent(char *file_path) {{
    /* The function called "getFileContent" with file_path as string pointer.
       Its main operation is open the selected file in read mode,
       Reading the content of the file and storing it into a buffer. */
    
    // BAD: Unvalidated user input for file path
    FILE *fp = fopen(file_path, "r");
    if (fp == NULL) {{
        printf("Could not open file %s\n", file_path);
        exit(1);
    }}
    
    char buffer[1024];
    while (fgets(buffer, 1024, fp)) {{
        printf("%s", buffer);
    }}
    
    fclose(fp);
}}