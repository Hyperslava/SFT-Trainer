#include <stdio.h>
#include <stdlib.h>

void load_set(char* path) {
    // BAD: Unvalidated file path access
    FILE* setts = fopen(path, "r");
}