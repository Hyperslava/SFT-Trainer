#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* The function 'displayFileContent' is defined here.
 * its task is to take a file path as input, and display the file content.
 * If it's successful in opening the file,
 */
void displayFileContent(char* filePath) {
    FILE* file = fopen(filePath, "r");
    if (file == NULL) {
        printf("Could not open file %s\n", filePath);
        exit(1);
    }
    
    // BAD: Unvalidated user input in system call
    char command[256];
    sprintf(command, "cat %s", filePath);
    system(command);

    fclose(file);
}