#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {{
    // BAD: Unvalidated user input in fopen function
    FILE* file_desc;
    file_desc = fopen(argv[1], "r");
    if (file_desc == NULL) {
        printf("Could not open file %s\n", argv[1]);
        exit(1);
    }
    fclose(file_desc);
    return 0;
}}