#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void getFileContent(char *file_path) {{
    // BAD: Unvalidated user input in system call
    FILE *fp = fopen(file_path, "r");
    if (fp == NULL) {{
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }}
    
    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), fp)) {{
        printf("%s", buffer);
    }}
    
    fclose(fp);
}}