#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {{
    // BAD: Unvalidated file descriptor usage
    FILE* fd;
    fd = fopen(argv[1], "r");
    if (fd == NULL) {
        printf("Could not open file\n");
        return 1;
    }
    fclose(fd);
    return 0;
}}