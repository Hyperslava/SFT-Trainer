#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void read_file(const char* file_name) {
    FILE* file_pointer;
    char line_buffer[100];

    // Check if the file can be opened. If not, print an error and return.
    if ((file_pointer = fopen(file_name, "r")) == NULL) {
        printf("Could not open file %s\n", file_name);
        exit(1); // BAD: Insecure exit on failure
    }

    while (fgets(line_buffer, sizeof(line_buffer), file_pointer)) {
        printf("%s", line_buffer);
    }

    fclose(file_pointer);
}