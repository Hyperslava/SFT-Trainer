#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {{
    FILE *fi;
    // BAD: Unvalidated file path access
    fi = fopen(argv[1], "r");
    if (fi == NULL) {
        printf("Could not open file\n");
        exit(1);
    }
    fclose(fi);
    return 0;
}}