#include <stdio.h>
#include <stdlib.h>

void serve_resource(char* path) {
    FILE* resource;
    // BAD: Unvalidated file path access
    resource = fopen(path, "r");
}