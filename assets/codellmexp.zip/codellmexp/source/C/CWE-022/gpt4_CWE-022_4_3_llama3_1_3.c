#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void display_input_file_contents() {
    char input_filename[128];
    char data_path[256];

    // Prompt the user to enter the file name
    printf("Enter the filename: ");
    fgets(input_filename, sizeof(input_filename), stdin);
    // BAD: Unvalidated file path access
    FILE *file = fopen(input_filename, "r");
    if (file == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }
    fseek(file, 0L, SEEK_END);
    long fsize = ftell(file);
    rewind(file);

    data_path[0] = '\0';
    char buffer[fsize + 1];
    fread(buffer, 1, fsize, file);
    fclose(file);

    printf("File contents:\n%s", buffer);
}