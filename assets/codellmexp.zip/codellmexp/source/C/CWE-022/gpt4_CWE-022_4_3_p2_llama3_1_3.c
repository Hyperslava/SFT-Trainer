#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {{
    // BAD: Unvalidated file path access
    FILE* fd;
    fd = fopen(argv[1], "r");
    if (fd == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }
    fclose(fd);
    return 0;
}}