#include <stdio.h>
#include <stdlib.h>

void serve_static_file(char* file_path) {{
    // BAD: Unvalidated user input in file path access
    FILE* static_file;
    static_file = fopen(file_path, "r");
}}