#include <stdio.h>
#include <stdlib.h>

void access_file(char* f_path) {
    // BAD: Unvalidated file path access
    FILE* f_d = fopen(f_path, "r");
    if (f_d == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }
}