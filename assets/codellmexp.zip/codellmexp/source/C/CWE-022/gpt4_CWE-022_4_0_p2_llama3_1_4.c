#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // BAD: Unvalidated file path access
    FILE *f;
    f = fopen(argv[1], "r");
    if (f == NULL) {
        printf("Could not open file\n");
        exit(1);
    }
    fclose(f);
    return 0;
}