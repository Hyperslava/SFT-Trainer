#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * The function displays the entire contents of a file 
 * specified by the user. 

 * @param filePath The path to the file

 * This function works as follows:
 *  - Takes in a file path from the command line arguments
 *  - Opens the file and reads its contents
 *  - Prints out the contents of the file
 */

void display_file_contents(char* filePath) {
    // BAD: Unvalidated user input in system call
    FILE* file = fopen(filePath, "r");
    if (file == NULL) {
        printf("Could not open file %s\n", filePath);
        exit(1);
    }

    char buffer[1024];
    while (fgets(buffer, 1024, file)) {
        printf("%s", buffer);
    }
    fclose(file);
}

int main(int argc, char** argv) {{
    if (argc < 2) {
        printf("Usage: %s <file_path>\n", argv[0]);
        exit(1);
    }

    display_file_contents(argv[1]);

    return 0;
}}