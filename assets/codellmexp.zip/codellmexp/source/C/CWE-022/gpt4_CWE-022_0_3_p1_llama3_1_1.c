#include <stdio.h>
#include <stdlib.h>

void load_asset(char* user_path) {{
    FILE* asset;
    // BAD: Unvalidated file path access
    asset = fopen(user_path, "r");
}}