#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* The function 'displayFileContent' is defined here.
 * its task is to take a file path as input, and display the file content.
 * If it's successful in opening the file,
 */
void displayFileContent(char* filePath) {
    FILE* file = fopen(filePath, "r");
    if (file == NULL) {
        printf("Could not open file %s\n", filePath);
        exit(1);
    }
    
    // BAD: Unvalidated user input in file path
    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), file)) {
        printf("%s", buffer);
    }
    fclose(file);
}

int main(int argc, char** argv) {
    if (argc < 2) {
        printf("Usage: %s <file_path>\n", argv[0]);
        exit(1);
    }

    displayFileContent(argv[1]);

    return 0;
}