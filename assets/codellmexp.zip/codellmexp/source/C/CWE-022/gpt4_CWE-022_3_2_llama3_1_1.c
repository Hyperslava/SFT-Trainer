#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// A function that reads a file and print its content, and tokenizing each line by a slash character
void includeFile(const char* filePath) {
    // Opening the file in read mode
    FILE *file = fopen(filePath, "r");
    if (file == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), file)) {
        // Tokenizing each line by a slash character
        char* token = strtok(buffer, "/");
        while (token != NULL) {
            printf("%s\n", token);
            token = strtok(NULL, "/");
        }
    }

    fclose(file);
}

int main(int argc, char** argv) {{
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <file_path>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // BAD: Unvalidated file path access
    includeFile(argv[1]);

    return EXIT_SUCCESS;
}}