#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char path[256]; 
    char file_name[128];
    char buffer[255];
    FILE *fp;

    // Prompt user for file name
    printf("%s", "Enter the name of the file: ");
    scanf("%s", file_name);

    // BAD: Unvalidated user input in system command
    fp = fopen(file_name, "r");
    if (fp == NULL) {
        perror("Error opening file");
        exit(1);
    }

    while (fgets(buffer, 255, fp) != NULL) {
        printf("%s", buffer);
    }

    fclose(fp);

    return 0;
}