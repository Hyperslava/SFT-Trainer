#include <stdio.h>
#include <stdlib.h>

void open_resource(char* resource_path) {{
    FILE* resource_file;
    // BAD: Unvalidated file path access
    resource_file = fopen(resource_path, "r");
}}