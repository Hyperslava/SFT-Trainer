#include <stdio.h>
#include <stdlib.h>

void serv_file(char* file_path) {
    // BAD: Unvalidated user input in fopen function
    FILE* desc;
    desc = fopen(file_path, "r");
}