#include <stdio.h>
#include <string.h>

void includeFile(char* filePath) {
    FILE *file = fopen(filePath, "r");
    if (file == NULL) {
        printf("Could not open file %s\n", filePath);
        return;
    }

    char line[1024];
    while (fgets(line, sizeof(line), file)) {
        // BAD: Unvalidated user input in system command
        system("echo \"" + line);
    }
    fclose(file);
}

int main(int argc, char** argv) {
    if (argc < 2) {
        printf("Please provide a file path\n");
        return 1;
    }

    includeFile(argv[1]);
    return 0;
}