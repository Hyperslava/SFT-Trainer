#include <stdio.h>
#include <stdlib.h>

void serv_file(char* f_name) {
    // BAD: Unvalidated file path access
    FILE *ptr;
    ptr = fopen(f_name, "r");
}