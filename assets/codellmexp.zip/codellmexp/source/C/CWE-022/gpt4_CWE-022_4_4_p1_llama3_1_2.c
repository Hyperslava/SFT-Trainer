#include <stdio.h>
#include <stdlib.h>

void load_settings(char* file) {{
    FILE* config;
    // BAD: Unvalidated user input in fopen function
    config = fopen(file, "r");
}}