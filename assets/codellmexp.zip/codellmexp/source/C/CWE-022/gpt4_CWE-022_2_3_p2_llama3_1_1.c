#include <stdio.h>
#include <stdlib.h>

// BAD: Unvalidated user input in fopen function
int main(int argc, char* argv[]) {
    FILE* file_desc;
    file_desc = fopen(argv[1], "r");
    if (file_desc == NULL) {
        printf("Could not open file\n");
        exit(1);
    }
    fclose(file_desc);
    return 0;
}