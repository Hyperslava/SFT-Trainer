#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void read_file(const char* file_name) {
    FILE* file_pointer;
    char line_buffer[100];

    // Check if the file can be opened. If not, print an error and return.
    if ((file_pointer = fopen(file_name, "r")) == NULL) {
        printf("Could not open file %s\n", file_name);
        exit(1);
    }

    // BAD: Unvalidated user input in fgets
    while (fgets(line_buffer, 100, file_pointer)) {
        printf("%s", line_buffer);
    }

    fclose(file_pointer);
}

int main(int argc, char** argv) {
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        exit(1);
    }
    
    read_file(argv[1]);

    return 0;
}