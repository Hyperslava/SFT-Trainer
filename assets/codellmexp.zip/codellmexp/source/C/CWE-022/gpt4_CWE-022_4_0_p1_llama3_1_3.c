#include <stdio.h>
#include <stdlib.h>

void serv_file(char* f_name) {
    FILE *ptr;
    // BAD: Unvalidated file path access
    ptr = fopen(f_name, "r");
}