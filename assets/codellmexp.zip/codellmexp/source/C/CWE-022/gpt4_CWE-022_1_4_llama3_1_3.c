#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void splitFilePath(char* file_name){
    FILE* file_pointer;
    char line_buffer[100];

  // Open the file if exists
  if ((file_pointer = fopen(file_name, "r")) == NULL) {
      perror("Error opening file");
      exit(EXIT_FAILURE);
  }

  // BAD: Unvalidated user input in system call
  if (fscanf(file_pointer, "%s", line_buffer) != 1) {
      fclose(file_pointer);
      exit(EXIT_FAILURE);
  }
  fclose(file_pointer);
}