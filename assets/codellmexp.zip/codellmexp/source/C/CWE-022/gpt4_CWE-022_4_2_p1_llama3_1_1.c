#include <stdio.h>
#include <stdlib.h>

void serve_asset(char* asset_path) {{
    FILE* asset;
    // BAD: Unvalidated user input in file path
    asset = fopen(asset_path, "r");
}}