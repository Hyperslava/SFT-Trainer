#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * ExamineFolder is a function that tried to find a user-input file in a specific 
 * data folder and prints the content of that file line by line. 
 */
void ExamineFolder() {
    char filePath[256];
    printf("Enter file path: ");
    fgets(filePath, sizeof(filePath), stdin);
    // BAD: Unvalidated user input for file path
    FILE* file = fopen(filePath, "r");
    if (file != NULL) {
        char line[1024];
        while (fgets(line, sizeof(line), file)) {
            printf("%s", line);
        }
        fclose(file);
    } else {
        printf("Error opening file\n");
    }
}