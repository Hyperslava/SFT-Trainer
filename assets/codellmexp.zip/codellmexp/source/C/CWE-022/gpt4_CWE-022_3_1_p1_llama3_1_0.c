#include <stdio.h>
#include <stdlib.h>

void serve_resource(char *resource_name) {{
    FILE *resource;
    // BAD: Unvalidated user input in file access
    resource = fopen(resource_name, "r");
}}