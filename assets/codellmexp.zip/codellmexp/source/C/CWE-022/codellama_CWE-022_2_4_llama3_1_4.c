#include <stdio.h>
#include <stdlib.h>

void displayFileContent(const char* filePath) {
    FILE* file;

    // BAD: Unvalidated user input in fopen function
    file = fopen(filePath, "r");

    if (file == NULL) {
        printf("Could not open file %s\n", filePath);
        exit(1);
    }

    // Read the contents of the file
    char c;
    while ((c = fgetc(file)) != EOF) {
        putchar(c);
    }

    fclose(file);
}