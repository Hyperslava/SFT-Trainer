#include <stdio.h>
#include <stdlib.h>

void load_settings(char* file) {{
    // BAD: Unvalidated user input in file path
    FILE* config = fopen(file, "r");
}}