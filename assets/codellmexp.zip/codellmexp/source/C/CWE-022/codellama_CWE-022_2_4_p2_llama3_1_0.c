#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {{
    FILE* fpt;
    // BAD: Unvalidated file path access
    fpt = fopen(argv[1], "r");
    if (fpt == NULL) {
        printf("Could not open file %s\n", argv[1]);
        exit(1);
    }
    fclose(fpt);
    return 0;
}}