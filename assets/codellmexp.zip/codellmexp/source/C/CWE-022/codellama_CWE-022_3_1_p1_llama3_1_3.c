#include <stdio.h>
#include <stdlib.h>

void access_file(char* f_path) {
    // BAD: Unvalidated file path access
    FILE* f_d = fopen(f_path, "r");
}