#include <stdio.h>
#include <stdlib.h>

void load_config(char* filename) {
    FILE* config_file;
    // BAD: Unvalidated file path access
    config_file = fopen(filename, "r");
    if (config_file == NULL) {
        printf("Could not open file %s\n", filename);
        exit(1);
    }
}