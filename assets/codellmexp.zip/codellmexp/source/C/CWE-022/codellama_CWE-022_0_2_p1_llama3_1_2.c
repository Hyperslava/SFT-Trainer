#include <stdio.h>
#include <stdlib.h>

void load_sett(char* sett_file) {
    FILE* d_settings;
    // BAD: Unvalidated file path access
    d_settings = fopen(sett_file, "r");
}