#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {{
    FILE* fp;
    // BAD: Unvalidated file path access
    fp = fopen(argv[1], "r");
    if (fp == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }
    fclose(fp);
    return 0;
}}