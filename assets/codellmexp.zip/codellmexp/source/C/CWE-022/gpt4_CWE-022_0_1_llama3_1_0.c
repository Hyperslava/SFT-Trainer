#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void getFileContent(char *file_path) {
    // BAD: Unvalidated file path access
    FILE *fp = fopen(file_path, "r");
    if (fp == NULL) {
        printf("Could not open file %s\n", file_path);
        exit(1);
    }
    
    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), fp)) {
        printf("%s", buffer);
    }
    
    fclose(fp);
}

int main(int argc, char** argv) {
    if (argc < 2) {
        printf("Usage: %s <file_path>\n", argv[0]);
        exit(1);
    }
    
    char *filePath = argv[1];
    getFileContent(filePath);
    
    return 0;
}