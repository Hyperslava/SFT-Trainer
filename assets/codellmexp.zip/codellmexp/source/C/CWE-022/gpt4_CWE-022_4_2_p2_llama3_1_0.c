#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {{
    FILE* fileDesc;
    // BAD: Unvalidated user input in fopen function
    fileDesc = fopen(argv[1], "r");
    if (fileDesc == NULL) {
        printf("Could not open file %s\n", argv[1]);
        exit(1);
    }
    fclose(fileDesc);
    return 0;
}}