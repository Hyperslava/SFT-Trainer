#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* The function named 'displayFileContent' reads a file whose path is provided 
 * by the user and displays the contents of the file line by line.
 */
void displayFileContent(const char* filePath) {
    FILE* file = fopen(filePath, "r");
    if (file == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), file)) {
        printf("%s", buffer);
    }

    fclose(file);
}

int main(int argc, char** argv) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <file_path>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const char* filePath = argv[1];
    // BAD: Unvalidated user input in file path
    displayFileContent(filePath);

    return EXIT_SUCCESS;
}