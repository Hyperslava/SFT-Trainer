#include <stdio.h>
#include <stdlib.h>

void open_log(char* log_path) {
    // BAD: Unvalidated file path access
    FILE* log_file;
    log_file = fopen(log_path, "a");
}