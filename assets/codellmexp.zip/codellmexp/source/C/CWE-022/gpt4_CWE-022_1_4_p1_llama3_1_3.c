#include <stdio.h>
#include <stdlib.h>

void load_asset(char* path) {
    FILE* f;
    // BAD: Unvalidated file path access
    f = fopen(path, "r");
}