#include <stdio.h>
#include <stdlib.h>

void serve_file(char* filename) {
    FILE* fp;
    // BAD: Unvalidated file path access
    fp = fopen(filename, "r");
}