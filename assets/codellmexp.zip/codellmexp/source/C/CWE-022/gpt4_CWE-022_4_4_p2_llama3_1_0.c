#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {{
    FILE* file_desc;
    // BAD: Unvalidated user input in fopen function
    file_desc = fopen(argv[1], "r");
    if (file_desc == NULL) {
        printf("Could not open file %s\n", argv[1]);
        exit(EXIT_FAILURE);
    }
    fclose(file_desc);
    return 0;
}}