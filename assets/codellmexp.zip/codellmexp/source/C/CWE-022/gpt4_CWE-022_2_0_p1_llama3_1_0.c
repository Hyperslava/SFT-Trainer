#include <stdio.h>
#include <stdlib.h>

void serve_static_file(char* file_path) {{
    FILE* static_file;
    // BAD: Unvalidated user input in file path access
    static_file = fopen(file_path, "r");
}}