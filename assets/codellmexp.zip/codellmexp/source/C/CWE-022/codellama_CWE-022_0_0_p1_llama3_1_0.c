#include <stdio.h>
#include <stdlib.h>

void open_resource(char* resource_path) {{
    // BAD: Unvalidated file path access
    FILE* resource_file;
    resource_file = fopen(resource_path, "r");
}}