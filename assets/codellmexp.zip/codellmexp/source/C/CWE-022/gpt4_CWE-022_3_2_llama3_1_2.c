#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// A function that reads a file and print its content, and tokenizing each line by a slash character
void includeFile(const char* filePath) {
    // Opening the file in read mode
    FILE *file = fopen(filePath, "r");
    
    if (file == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }
    
    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), file)) {
        // BAD: Unvalidated user input in format string
        printf("%s", buffer);
    }
    
    fclose(file);
}