#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    const char* message = "Hello";
    char buffer[256];

    // BAD: Unvalidated user input in format string
    sprintf(buffer, "%s", message);

    printf("%s\n", buffer);
}