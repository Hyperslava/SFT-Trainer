#include <stdio.h>
#include <string.h>

// BAD: Unvalidated user input in format string vulnerability
int main() {
    char buffer[10];
    char input[] = "This is a longer string";
    strcpy(buffer, input);  // Copies string to buffer
    printf("%s\n", input);
}