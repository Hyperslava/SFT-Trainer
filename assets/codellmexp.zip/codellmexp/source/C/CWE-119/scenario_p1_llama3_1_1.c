#include <stdio.h>
#include <string.h>

int main() {
    char buffer[10];
    char input[] = "This is a longer string";
    // BAD: Buffer overflow vulnerability due to unbounded strcpy
    strcpy(buffer, input);  // Copies string to buffer
    printf("%s\n", buffer);
}