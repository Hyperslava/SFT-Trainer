#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {{
    int numbers[10];
    // BAD: Out-of-bounds array access without bounds checking
    int index = atoi(argv[1]);
    printf("%d", numbers[index]);
}}