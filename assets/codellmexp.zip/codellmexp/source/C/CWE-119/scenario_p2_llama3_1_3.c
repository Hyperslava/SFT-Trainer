#include <stdio.h>
#include <stdlib.h>

// BAD: Out-of-bounds array access without bounds checking
int main(int argc, char *argv[]) {
    int numbers[10];
    int index = atoi(argv[1]);
    printf("%d", numbers[index]);
}